package com.zxl.mapper;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zxl.entity.TestData;
import com.zxl.service.TestDataService;

@RestController
public class TestDataController {

    @Autowired
    private TestDataService testDataService;

    /**
     * 查询所有记录
     *
     * @return 返回集合，没有返回空List
     */
    @RequestMapping("list")
    public List<TestData> listAll() {
        return testDataService.listAll();
    }


    /**
     * 根据主键查询
     *
     * @param id 主键
     * @return 返回记录，没有返回null
     */
    @RequestMapping("getById")
    public TestData getById(Long id) {
        return testDataService.getById(id);
    }    
     
    /**
     * 新增，忽略null字段
     *
     * @param testData 新增的记录
     * @return 返回影响行数
     */
    @RequestMapping("insert")
    public int insert(@RequestBody TestData testData) {
        return testDataService.insertIgnoreNull(testData);
    }    
      
    /**
     * 修改，忽略null字段
     *
     * @param testData 修改的记录
     * @return 返回影响行数
     */
    @RequestMapping("update")
    public int update(@RequestBody TestData testData) {
        return testDataService.updateIgnoreNull(testData);
    }
    
    /**
     * 删除记录
     *
     * @param testData 待删除的记录
     * @return 返回影响行数
     */
    @RequestMapping("delete")
    public int delete(@RequestBody TestData testData) {
        return testDataService.delete(testData);
    }
    
}